﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxController : Controller
    {
        public AjaxController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }



        public IActionResult Index(int ID)
        {
            var x = db.OdrzanCas.Include(a => a.Skola).Include(a => a.Odjeljenje).Include(a => a.Predmet)
               .Where(a => a.OdrzanCasID == ID).FirstOrDefault();
            DetaljiUcesniciVM model = new DetaljiUcesniciVM
            {
                OdrzanCasID = ID,
                redovi = db.OdrzanCasDetalji.Where(a => a.OdrzanCasID == ID).Select(s => new DetaljiUcesniciVM.RowAjax
                {
                    OdrzanCasUcesnikID = s.OdrzanCasDetaljiID,
                    Ocjena = s.Ocjena,
                    OpravdanoOdsutan = s.OpravdanoOdsutan,
                    Pristuan = s.Prisutan,
                    Ucenik = s.OdjeljenjeStavka.Ucenik.ImePrezime
                }).ToList()
            };
            return PartialView(model);
        }

        public IActionResult UcenikNijePristupio (int UcID)
        {
            var ucenik = db.OdrzanCasDetalji.Where(s => s.OdrzanCasDetaljiID == UcID).FirstOrDefault();
            ucenik.Prisutan = false;
            db.SaveChanges();
            return Redirect("/OdrzanaNastava/Detalji?ID=" + ucenik.OdrzanCasID);
        }

        public IActionResult UcenikJePristupio(int UcID)
        {
            var ucenik = db.OdrzanCasDetalji.Where(s => s.OdrzanCasDetaljiID == UcID).FirstOrDefault();
            ucenik.Prisutan = true;
            db.SaveChanges();
            return Redirect("/OdrzanaNastava/Detalji?ID=" + ucenik.OdrzanCasID);
        }



















    }
}
