﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class OdrzanaNastavaController : Controller
    {
        public OdrzanaNastavaController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }


        public IActionResult Index()
        {
            IndexVM model = new IndexVM
            {
                podaci = db.Nastavnik.Select(s => new IndexVM.RowIndex
                {
                    Nastavnik = s.Ime + " " + s.Prezime,
                    NastavnikID = s.Id,
                    BrCasova = db.OdrzanCas.Where(x => x.NastavnikID == s.Id).Count()
                }).ToList()
            };
            return View(model);
        }


        public IActionResult Prikaz(int NastavnikID)
        {
            PrikazVM model = new PrikazVM
            {
                NastavnikID = NastavnikID,
                redovi = db.OdrzanCas.Where(x => x.NastavnikID == NastavnikID).Select(s => new PrikazVM.RowPrikaz
                {
                    OdrzanCasID = s.OdrzanCasID,
                    Datum = s.Datum,
                    NastavnikID = s.NastavnikID,
                    Predmet = s.Predmet.Naziv,
                    SkGodinaOdjeljenje = s.Odjeljenje.SkolskaGodina.Naziv + " " + s.Odjeljenje.Oznaka,
                    Skola = s.Skola.Naziv,
                    Ucenici = db.OdrzanCasDetalji.Where(x => x.OdrzanCasID == s.OdrzanCasID && x.Prisutan == false).Select(a => new SelectListItem
                    {
                        Value = a.OdjeljenjeStavka.UcenikId.ToString(),
                        Text = a.OdjeljenjeStavka.Ucenik.ImePrezime
                    }).ToList()
                }).ToList()
            };
            return View(model);
        }

        public IActionResult Dodaj(int NastavnikID)
        {
            DodajVM model = new DodajVM
            {
                NastavnikID = NastavnikID,
                Nastavnik = db.Nastavnik.Where(x => x.Id == NastavnikID).Select(s => s.Ime + " " + s.Prezime).FirstOrDefault(),
                Odjeljenja = db.Odjeljenje.Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Oznaka
                }).ToList(),
                Skole = db.Skola.Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv
                }).ToList(),
                Predmeti = db.Predmet.Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv
                }).ToList(),
            };
            return View(model);
        }

        public IActionResult Snimi(DodajVM podaci)
        {
            OdrzanCas o = new OdrzanCas
            {
                Datum = podaci.Datum,
                NastavnikID = podaci.NastavnikID,
                OdjeljenjeID = podaci.OdjeljenjeID,
                PredmetID = podaci.PredmetID,
                SadrzajCasa = podaci.Sadrzaj,
                SkolaID = podaci.SkolaID
            };
            db.OdrzanCas.Add(o);

            OdrzanCasDetalji oc = new OdrzanCasDetalji
            {
                OdrzanCas = o,
                Prisutan = false,
                OpravdanoOdsutan = false,
                OdjeljenjeStavkaID = db.OdjeljenjeStavka.Select(x => x.Id).FirstOrDefault()
            };
            db.OdrzanCasDetalji.Add(oc);
            db.SaveChanges();
            return Redirect("/OdrzanaNastava/Prikaz?NastavnikID=" + podaci.NastavnikID);
        }

        public IActionResult Detalji(int ID)
        {
            var x = db.OdrzanCas.Include(a => a.Skola).Include(a => a.Odjeljenje).Include(a => a.Predmet)
                .Where(a => a.OdrzanCasID == ID).FirstOrDefault();

            DetaljiVM model = new DetaljiVM
            {
                Datum = x.Datum,
                OdrzanCasID = ID,
                sadrzaj = x.SadrzajCasa,
                SkOdjeljenjePredmet = x.Skola.Naziv + "/" + x.Odjeljenje.Oznaka + "/" + x.Predmet.Naziv
            };
            return View(model);
        }

        public IActionResult Obrisi(int ID)
        {
            var NastavnikID = db.OdrzanCas.Where(x => x.OdrzanCasID == ID).Select(s => s.NastavnikID);
            var Detalj = db.OdrzanCasDetalji.Where(x => x.OdrzanCasID == ID);
            foreach (var x in Detalj)
            {
                db.OdrzanCasDetalji.Remove(x);
            }
            var cas = db.OdrzanCas.Where(x => x.OdrzanCasID == ID).SingleOrDefault();
            db.OdrzanCas.Remove(cas);
            db.SaveChanges();
            return Redirect("/OdrzanaNastava/Prikaz?NastavnikID=" + NastavnikID);
        }












    }
}
