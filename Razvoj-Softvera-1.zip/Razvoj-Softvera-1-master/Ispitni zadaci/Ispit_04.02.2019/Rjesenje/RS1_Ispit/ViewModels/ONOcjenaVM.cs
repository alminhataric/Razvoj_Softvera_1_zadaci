﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class ONOcjenaVM
    {
        public int ONUcesnikID { get; set; }
        public string ONUcesnik { get; set; }
        public int OCasID { get; set; }
        public int Ocjena { get; set; }
    }
}
