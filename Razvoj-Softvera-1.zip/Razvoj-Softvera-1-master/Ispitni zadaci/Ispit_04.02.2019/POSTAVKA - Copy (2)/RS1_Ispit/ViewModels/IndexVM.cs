﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class IndexVM : Controller
    {
        public List<RowIndex> redovi { get; set; }
        public class RowIndex { 
            public string Nastavnik { get; set; }
            public int NastavnikID { get; set; }
            public int BrCasova { get; set; }
        }
    }
}
