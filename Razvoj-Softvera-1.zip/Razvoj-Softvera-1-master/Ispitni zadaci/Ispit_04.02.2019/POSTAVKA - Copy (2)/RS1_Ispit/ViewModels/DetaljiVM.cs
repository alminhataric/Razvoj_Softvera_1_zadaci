﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class DetaljiVM : Controller
    {
        public int OdrzanCasID { get; set; }
        public DateTime Datum { get; set; }
        public string SkOdjeljenjePredmet { get; set; }
        public string Sadrzaj { get; set; }
    }
}
