﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace RS1_Ispit_asp.net_core.Migrations
{
    public partial class Pocetna : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OdrzanCas",
                columns: table => new
                {
                    OdrzanCasID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Datum = table.Column<DateTime>(nullable: false),
                    NastavnikID = table.Column<int>(nullable: false),
                    OdjeljenjeID = table.Column<int>(nullable: false),
                    PredmetID = table.Column<int>(nullable: false),
                    SadrzajCasa = table.Column<string>(nullable: true),
                    SkolaID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OdrzanCas", x => x.OdrzanCasID);
                    table.ForeignKey(
                        name: "FK_OdrzanCas_Nastavnik_NastavnikID",
                        column: x => x.NastavnikID,
                        principalTable: "Nastavnik",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_OdrzanCas_Odjeljenje_OdjeljenjeID",
                        column: x => x.OdjeljenjeID,
                        principalTable: "Odjeljenje",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_OdrzanCas_Predmet_PredmetID",
                        column: x => x.PredmetID,
                        principalTable: "Predmet",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_OdrzanCas_Skola_SkolaID",
                        column: x => x.SkolaID,
                        principalTable: "Skola",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "OdrzanCasDetalji",
                columns: table => new
                {
                    OdrzanCasDetaljiID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Ocjena = table.Column<int>(nullable: false),
                    OdjeljenjeStavkaID = table.Column<int>(nullable: false),
                    OdrzanCasID = table.Column<int>(nullable: false),
                    OpravdanoOdsutan = table.Column<bool>(nullable: false),
                    Prisutan = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OdrzanCasDetalji", x => x.OdrzanCasDetaljiID);
                    table.ForeignKey(
                        name: "FK_OdrzanCasDetalji_OdjeljenjeStavka_OdjeljenjeStavkaID",
                        column: x => x.OdjeljenjeStavkaID,
                        principalTable: "OdjeljenjeStavka",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_OdrzanCasDetalji_OdrzanCas_OdrzanCasID",
                        column: x => x.OdrzanCasID,
                        principalTable: "OdrzanCas",
                        principalColumn: "OdrzanCasID",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCas_NastavnikID",
                table: "OdrzanCas",
                column: "NastavnikID");

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCas_OdjeljenjeID",
                table: "OdrzanCas",
                column: "OdjeljenjeID");

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCas_PredmetID",
                table: "OdrzanCas",
                column: "PredmetID");

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCas_SkolaID",
                table: "OdrzanCas",
                column: "SkolaID");

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCasDetalji_OdjeljenjeStavkaID",
                table: "OdrzanCasDetalji",
                column: "OdjeljenjeStavkaID");

            migrationBuilder.CreateIndex(
                name: "IX_OdrzanCasDetalji_OdrzanCasID",
                table: "OdrzanCasDetalji",
                column: "OdrzanCasID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OdrzanCasDetalji");

            migrationBuilder.DropTable(
                name: "OdrzanCas");
        }
    }
}
