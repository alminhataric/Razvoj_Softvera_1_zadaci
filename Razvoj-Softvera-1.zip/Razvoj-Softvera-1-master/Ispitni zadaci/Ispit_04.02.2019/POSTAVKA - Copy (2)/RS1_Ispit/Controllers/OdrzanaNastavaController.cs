﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class OdrzanaNastavaController : Controller
    {
        public OdrzanaNastavaController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }

        public IActionResult Index()
        {
            IndexVM model = new IndexVM
            {
                redovi = db.Nastavnik.Select(s => new IndexVM.RowIndex
                {
                    Nastavnik = s.Ime + " " + s.Prezime,
                    NastavnikID = s.Id,
                    BrCasova = db.OdrzanCas.Where(x => x.NastavnikID == s.Id).Count()
                }).ToList()
            };
            return View(model);
        }

        public IActionResult Odaberi(int NastavnikID)
        {
            OdaberiVM model = new OdaberiVM
            {
                NastavnikID = NastavnikID,
                redovi = db.OdrzanCas.Where(x => x.NastavnikID == NastavnikID).Select(s => new OdaberiVM.RowOdaberi
                {
                    OdrzanCasID = s.OdrzanCasID,
                    NastavnikID = s.NastavnikID,
                    Datum = s.Datum,
                    Skola = s.Skola.Naziv,
                    SkGOdjeljenje = s.Odjeljenje.SkolskaGodina.Naziv + "/" + s.Odjeljenje.Oznaka,
                    Predmet = s.Predmet.Naziv,
                    Ucenici = db.OdrzanCasDetalji.Where(x => x.OdrzanCasID == s.OdrzanCasID && x.Prisutan == false).Select(t => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                    {
                        Value = t.OdjeljenjeStavka.UcenikId.ToString(),
                        Text = t.OdjeljenjeStavka.Ucenik.ImePrezime
                    }).ToList()
                }).ToList()
            };
            return View(model);
        }


        public IActionResult Dodaj(int NastavnikID)
        {
            DodajVM model = new DodajVM
            {
                NastavnikID = NastavnikID,
                Nastavnik = db.Nastavnik.Where(x => x.Id == NastavnikID).Select(x => x.Ime + " " + x.Prezime).FirstOrDefault(),
                Odjeljenja = db.Odjeljenje.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Oznaka
                }).ToList(),
                Skole = db.Skola.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv
                }).ToList(),
                Predmeti = db.Predmet.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv
                }).ToList(),
            };
            return View(model);
        }


        public IActionResult Snimi(DodajVM podaci)
        {
            OdrzanCas c = new OdrzanCas
            {
                SkolaID = podaci.SkolaID,
                OdjeljenjeID = podaci.OdjeljenjeID,
                PredmetID = podaci.PredmetID,
                Datum = DateTime.Now,
                SadrzajCasa = podaci.Sadrzaj,
                NastavnikID = podaci.NastavnikID
            };
            db.OdrzanCas.Add(c);

            OdrzanCasDetalji ocd = new OdrzanCasDetalji
            {
                OdrzanCas = c,
                Prisutan = false,
                OpravdanoOdsutan = false,
                OdjeljenjeStavkaID = db.OdjeljenjeStavka.Select(x => x.Id).FirstOrDefault()
            };
            db.OdrzanCasDetalji.Add(ocd);
            db.SaveChanges();
            return Redirect("/OdrzanaNastava/Odaberi?NastavnikID=" + podaci.NastavnikID);
        }


        public IActionResult Detalji(int OdrzanCasID)
        {
            var x = db.OdrzanCas.Include(a => a.Skola).Include(a => a.Odjeljenje).Include(a => a.Predmet)
                .Where(a => a.OdrzanCasID == OdrzanCasID).FirstOrDefault();

            DetaljiVM model = new DetaljiVM
            {
                Datum = x.Datum,
                OdrzanCasID = OdrzanCasID,
                Sadrzaj = x.SadrzajCasa,
                SkOdjeljenjePredmet = x.Skola.Naziv + "/" + x.Odjeljenje.Oznaka + "/" + x.Predmet.Naziv
            };
            return View(model);
        }











    }
}
