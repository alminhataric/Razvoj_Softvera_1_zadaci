﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class DodajVM : Controller
    {
        public int SkolaID { get; set; }
        public int PredmetID { get; set; }
        public List<SelectListItem> Predmet { get; set; }
        public List<SelectListItem> Skole { get; set; }
        public DateTime Datum { get; set; }
        public bool Zakljucano { get; set; }

    }
}
