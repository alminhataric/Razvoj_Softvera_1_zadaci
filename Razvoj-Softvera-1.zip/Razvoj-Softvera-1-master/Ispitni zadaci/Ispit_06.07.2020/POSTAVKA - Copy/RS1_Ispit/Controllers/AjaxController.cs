﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.ViewModels;
using static RS1_Ispit_asp.net_core.ViewModels.AjaxIndexVM;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxController : Controller
    {
        public AjaxController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }
        public IActionResult Index(int TakmicenjeID)
        {
            AjaxIndexVM model = new AjaxIndexVM
            {
                TakmicenjeID = TakmicenjeID,
                Zakljucano = db.Takmicenje.Where(x => x.TakmicenjeID == TakmicenjeID).Select(s => s.Zakljucano).FirstOrDefault(),
                podaci = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == TakmicenjeID).Select(s => new RowAjax
                {
                    bodovi = s.Bodovi,
                    BrDnevnik = s.OdjeljenjeStavka.BrojUDnevniku,
                    Odjeljenje = s.OdjeljenjeStavka.Odjeljenje.Oznaka,
                    Pristupio = s.Pristupio,
                    TakmicenjeUcesnikID = s.TakmicenjeUcesnikID
                }).ToList()
            };
            return PartialView(model);
        }
        public IActionResult UcenikJePristupio(int TkmUcID)
        {
            var tkm = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeUcesnikID == TkmUcID).Select(x => x.TakmicenjeID).FirstOrDefault();
            var ucenik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeUcesnikID == TkmUcID).FirstOrDefault();
            ucenik.Pristupio = false;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + tkm);
        }
        public IActionResult UcenikNijePristupio(int TkmUcID)
        {
            var tkm = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeUcesnikID == TkmUcID).Select(x => x.TakmicenjeID).FirstOrDefault();
            var ucenik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeUcesnikID == TkmUcID).FirstOrDefault();
            ucenik.Pristupio = true;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + tkm);
        }
    }
}
