﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class TakmicenjeController : Controller
    {
        public TakmicenjeController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }


       public IActionResult Index(int SkolaID = 0)
        {
            IndexVM model;
            if (SkolaID == 0)
            {
                model = new IndexVM
                {
                    Skole = db.Skola.Select(s => new SelectListItem
                    {
                        Value = s.Id.ToString(),
                        Text = s.Naziv
                    }).ToList(),
                    redovi = db.Takmicenje.Select(s => new IndexVM.RowIndex
                    {
                        TakmicenjeID = s.TakmicenjeID,
                        Razred = s.Razred,
                        Datum = s.Datum,
                        Skola = s.Skola.Naziv,
                        Predmet = s.Predmet.Naziv,
                        NajUcesnik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == s.TakmicenjeID).OrderByDescending(x=>x.Bodovi).
                        Select(x => x.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + "|"
                          + x.OdjeljenjeStavka.Odjeljenje.Oznaka + "|" + x.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                    }).ToList()
                };
            }
            else
            {
                model = new IndexVM
                {
                    SkolaID = SkolaID,
                    Skole = db.Skola.Select(s => new SelectListItem
                    {
                        Value = s.Id.ToString(),
                        Text = s.Naziv
                    }).ToList(),
                    redovi = db.Takmicenje.Where(x=>x.SkolaID == SkolaID).Select(s => new IndexVM.RowIndex
                    {
                        TakmicenjeID = s.TakmicenjeID,
                        Razred = s.Razred,
                        Datum = s.Datum,
                        Skola = s.Skola.Naziv,
                        Predmet = s.Predmet.Naziv,
                        NajUcesnik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == s.TakmicenjeID).OrderByDescending(x => x.Bodovi).
                        Select(x => x.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + "|"
                          + x.OdjeljenjeStavka.Odjeljenje.Oznaka + "|" + x.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                    }).ToList()
                };
            }
            return View(model);
        }

        public IActionResult Dodaj(int SkolaID)
        {
            DodajVM model = new DodajVM
            {
                SkolaID = SkolaID,
                Predmet = db.Predmet.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                Skole = db.Skola.Where(x => x.Id == SkolaID).Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                Datum = DateTime.Now
            };
            return View(model);
        }

        public IActionResult Snimi(DodajVM podaci)
        {
            Takmicenje t = new Takmicenje
            {
                SkolaID = podaci.SkolaID,
                PredmetID = podaci.PredmetID,
                Datum = podaci.Datum,
                Zakljucano = false,
                Razred = db.Odjeljenje.Where(x => x.SkolaID == podaci.SkolaID).Select(s => s.Razred).FirstOrDefault()
            };
            db.Takmicenje.Add(t);

            TakmicenjeUcesnik tu = new TakmicenjeUcesnik
            {
                Pristupio = false,
                Bodovi = 0,
                Takmicenje = t,
                OdjeljenjeStavkaID = db.OdjeljenjeStavka.Select(x => x.Id).FirstOrDefault()
            };
            db.TakmicenjeUcesnik.Add(tu);
            db.SaveChanges();
            return Redirect("/Takmicenje/Index?SkolaID=" + podaci.SkolaID);

        }


        public IActionResult Rezultati(int TakmicenjeID)
        {
            RezultatiVM model = db.Takmicenje.Where(x => x.TakmicenjeID == TakmicenjeID).Select(s => new RezultatiVM
            {
                Datum = s.Datum,
                Razred = s.Razred,
                TakmicenjeID = s.TakmicenjeID,
                Zakljucaj = s.Zakljucano,
                SkolaID = s.SkolaID,
                Skola = s.Skola.Naziv,
                Predmet = s.Predmet.Naziv
            }).FirstOrDefault();
            return View(model);
        }

        public IActionResult Zakljucaj(int TakmicenjeID)
        {
            var t = db.Takmicenje.Where(x => x.TakmicenjeID == TakmicenjeID).FirstOrDefault();
            t.Zakljucano = true;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + t.TakmicenjeID);

        }













    }
}
