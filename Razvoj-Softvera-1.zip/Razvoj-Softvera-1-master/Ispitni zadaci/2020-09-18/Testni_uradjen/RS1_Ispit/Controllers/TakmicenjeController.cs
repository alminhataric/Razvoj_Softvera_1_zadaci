﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class TakmicenjeController : Controller
    {
        public TakmicenjeController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }


        public IActionResult Index(int SkolaID = 0, int Razred = 0)
        {
            IndexVM model = new IndexVM();
            model.SkolaID = SkolaID;
            model.Skole = db.Skola.Select(s => new SelectListItem
            {
                Value = s.Id.ToString(),
                Text = s.Naziv
            }).ToList();
            if (Razred == 0)
            {
                model.redovi = db.Takmicenje.Where(x => x.SkolaID == SkolaID).Select(x => new IndexStavkeVM
                {
                    TakmicenjeID = x.TakmicenjeID,
                    Datum = x.Datum,
                    Predmet = x.Predmet.Naziv,
                    Razred = x.Predmet.Razred,
                    Skola = x.Skola.Naziv,
                    NajUcesnik = db.TakmicenjeUcesnik.Where(s => s.TakmicenjeID == x.TakmicenjeID).
                      OrderByDescending(s => s.Bodovi).Select(s => s.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + " | "
                      + s.OdjeljenjeStavka.Odjeljenje.Oznaka + " | " + s.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                }).ToList();
            }
            else
            {
                model.redovi = db.Takmicenje.Where(x => x.SkolaID == SkolaID && x.Razred == Razred).Select(x => new IndexStavkeVM
                {
                    TakmicenjeID = x.TakmicenjeID,
                    Datum = x.Datum,
                    Predmet = x.Predmet.Naziv,
                    Razred = x.Predmet.Razred,
                    Skola = x.Skola.Naziv,
                    NajUcesnik = db.TakmicenjeUcesnik.Where(s => s.TakmicenjeID == x.TakmicenjeID).
                      OrderByDescending(s => s.Bodovi).Select(s => s.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + " | "
                      + s.OdjeljenjeStavka.Odjeljenje.Oznaka + " | " + s.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                }).ToList();
            }
            return View(model);
        }


        public IActionResult Prikaz(int SkolaID, int Razred)
        {
            return Redirect("/Takmicenje/Index?SkolaID=" + SkolaID + "&Razred" + Razred);
        }


        public IActionResult Dodaj(int SkolaID)
        {
            DodajVM model = new DodajVM
            {
                SkolaID = SkolaID,
                Skole = db.Skola.Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv,
                }).ToList(),
                Predmeti = db.Predmet.Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Naziv,
                }).ToList(),
                Datum = DateTime.Now,
                

            };
            return View(model);
        }


        public IActionResult Snimi(DodajVM podaci)
        {
            Takmicenje t = new Takmicenje
            {
                Datum = DateTime.Now,
                PredmetID = podaci.PredmetID,
                SkolaID = podaci.SkolaID,
                Razred = db.Predmet.Where(x => x.Id == podaci.PredmetID).Select(x => x.Razred).FirstOrDefault()
                

            };
            db.Takmicenje.Add(t);

            TakmicenjeUcesnik tu = new TakmicenjeUcesnik
            {
                Takmicenje = t,
                Pristupio = false,
                Bodovi = 0,
                OdjeljenjeStavkaID = db.OdjeljenjeStavka.Select(x => x.Id).FirstOrDefault()
            };
            db.Takmicenje.Add(t);
            db.SaveChanges();
            return Redirect("/Takmicenje/Prikaz?SkolaID=" + podaci.SkolaID + "&Razred" + podaci.Razred);


        }
    }
}
