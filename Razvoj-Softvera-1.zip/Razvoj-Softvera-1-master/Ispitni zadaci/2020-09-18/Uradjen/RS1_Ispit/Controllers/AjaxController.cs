﻿using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxController : Controller
    {
        public AjaxController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }

        public IActionResult Index(int TakmicenjeID)
        {
            AjaxIndexVM model = new AjaxIndexVM
            {
                TakmicenjeID = TakmicenjeID,
                Zakljucano = db.Takmicenje.Where(x => x.TakmicenjeID == TakmicenjeID).Select(s => s.Zakljucano).FirstOrDefault(),
                redovi = db.TakmicenjeUcesnik.Where(s => s.TakmicenjeID == TakmicenjeID).Select(s => new AjaxIndexVM.RowAjax
                {
                    TakmicenjeUcesnikID = s.TakmicenjeUcesnikID,
                    Bodovi = s.Bodovi,
                    BrDnevnik = s.OdjeljenjeStavka.BrojUDnevniku,
                    Odjeljenje = s.OdjeljenjeStavka.Odjeljenje.Oznaka,
                    Pristupio = s.Pristuan
                }).ToList()
            };
            return PartialView(model);
        }


        public IActionResult UcenikNijePristupio(int UcID)
        {
            var ucenik = db.TakmicenjeUcesnik.Find(UcID);
            ucenik.Pristuan = false;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + ucenik.TakmicenjeID);
        }

        public IActionResult UcenikJePristupio(int UcID)
        {
            var ucenik = db.TakmicenjeUcesnik.Find(UcID);
            ucenik.Pristuan = true;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + ucenik.TakmicenjeID);
        }














    }
}
