﻿using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class TakmicenjeController : Controller
    {
        public TakmicenjeController(MojContext db)
        {
            this.db = db;
        }
        public MojContext db { get; }


        public IActionResult Index(int SkolaID =0, int Razred = 0)
        {
            IndexVM model;
            if (SkolaID == 0 && Razred == 0)
            {
                model = new IndexVM
                {
                    Skole = db.Skola.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                    {
                        Value = s.Id.ToString(),
                        Text = s.Naziv
                    }).ToList(),
                    podaci = db.Takmicenje.Select(s => new IndexStavkeVM
                    {
                        TakmicenjeID = s.TakmicenjeID,
                        Skola = s.Skola.Naziv,
                        Predmet = s.Predmet.Naziv,
                        Razred = s.Predmet.Razred,
                        Datum = s.Datum,
                        NajUcesnik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == s.TakmicenjeID).OrderByDescending(x => x.Bodovi)
                        .Select(x => x.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + "|" + x.OdjeljenjeStavka.Odjeljenje.Oznaka + "|" +
                        x.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                    }).ToList(),

                };
            }
            else if (SkolaID != 0)
            {
                model = new IndexVM
                {
                    Skole = db.Skola.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                    {
                        Value = s.Id.ToString(),
                        Text = s.Naziv
                    }).ToList(),
                    podaci = db.Takmicenje.Where(x => x.SkolaID == SkolaID &&  x.Predmet.Razred == Razred).Select(s => new IndexStavkeVM
                    {
                        TakmicenjeID = s.TakmicenjeID,
                        Skola = s.Skola.Naziv,
                        Predmet = s.Predmet.Naziv,
                        Razred = s.Predmet.Razred,
                        Datum = s.Datum,
                        NajUcesnik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == s.TakmicenjeID).OrderByDescending(x => x.Bodovi)
                          .Select(x => x.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + "|" + x.OdjeljenjeStavka.Odjeljenje.Oznaka + "|" +
                          x.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                    }).ToList(),
                };
            }
            else
            {
                model = new IndexVM
                {
                    Skole = db.Skola.Select(s => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                    {
                        Value = s.Id.ToString(),
                        Text = s.Naziv
                    }).ToList(),
                    podaci = db.Takmicenje.Where(x => x.Predmet.Razred == Razred && x.SkolaID == SkolaID).Select(s => new IndexStavkeVM
                    {
                        TakmicenjeID = s.TakmicenjeID,
                        Skola = s.Skola.Naziv,
                        Predmet = s.Predmet.Naziv,
                        Razred = s.Predmet.Razred,
                        Datum = s.Datum,
                        NajUcesnik = db.TakmicenjeUcesnik.Where(x => x.TakmicenjeID == s.TakmicenjeID).OrderByDescending(x => x.Bodovi)
                          .Select(x => x.OdjeljenjeStavka.Odjeljenje.Skola.Naziv + "|" + x.OdjeljenjeStavka.Odjeljenje.Oznaka + "|" +
                          x.OdjeljenjeStavka.Ucenik.ImePrezime).FirstOrDefault()
                    }).ToList(),
                };
            }
            return View(model);
        }

        //public IActionResult Prikaz(int SkolaID,int Razred)
        //{
        //    return Redirect("/Takmicenje/Index?SkolaID=" + SkolaID + "&Razred=" + Razred);
        //}



        public IActionResult Dodaj(int SkolaID)
        {
            Skola s = db.Skola.Find(SkolaID);
            DodajVM model = new DodajVM
            {
                Skole = db.Skola.Select(x => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                Predmet = db.Predmet.Select(x => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                Datum = DateTime.Now
            };
            return View(model);
        }

        public IActionResult Snimi(DodajVM podaci)
        {
            Takmicenje t = new Takmicenje
            {
                SkolaID = podaci.SkolaID,
                PredmetID = podaci.PredmetID,
                Datum = podaci.Datum,
                Zakljucano = false,

            };
            db.Add(t);

            TakmicenjeUcesnik tu = new TakmicenjeUcesnik
            {
                Takmicenje = t,
                Bodovi = 0,
                Pristuan = false,
                OdjeljenjeStavkaID = db.OdjeljenjeStavka.Select(x => x.Id).FirstOrDefault()
            };
            db.Add(tu);
            db.SaveChanges();
            return Redirect("/Takmicenje/Index?SkolaID=" + podaci.SkolaID);

        }


        public IActionResult Rezultati(int TakmicenjeID)
        {
            var t = db.Takmicenje.Find(TakmicenjeID);
            RezultatiVM model = db.Takmicenje.Where(x => x.TakmicenjeID == TakmicenjeID).Select(s => new RezultatiVM
            {
                TakmicenjeID = s.TakmicenjeID,
                SkolaID = s.SkolaID,
                Skola = s.Skola.Naziv,
                Predmet = s.Predmet.Naziv,
                Razred = s.Predmet.Razred,
                Datum = s.Datum,
                Zakljucaj = s.Zakljucano
            }).FirstOrDefault();
            return View(model);
        }

        public IActionResult Zakljucaj (int TakmicenjeID)
        {
            var x = db.Takmicenje.Find(TakmicenjeID);
            x.Zakljucano = true;
            db.SaveChanges();
            return Redirect("/Takmicenje/Rezultati?TakmicenjeID=" + TakmicenjeID);
        }


    }
}
