﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class Predmet
    {
        public int Id { get; set; }
        public string Naziv{ get; set; }
        public int Razred { get; set; }
    }
}
