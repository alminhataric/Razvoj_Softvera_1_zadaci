﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class SkolskaGodina
    {
        public int Id { get; set; }
        public string Naziv{ get; set; }
        public bool Aktuelna{ get; set; }
    }
}
